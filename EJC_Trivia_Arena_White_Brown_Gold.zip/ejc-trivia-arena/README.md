# EJC Trivia Arena

## Website preview
- `index.html` is the responsive homepage.
- `assets/ejc-overhead-banner.png` is the overhead banner provided by the organiser.

## Publish on a zero budget
1. Create a GitHub account if you do not already have one.
2. Create a public repository named `ejc-trivia-arena`.
3. Upload `index.html` and the `assets` folder (including the banner image).
4. In repository Settings → Pages, publish from the main branch and root folder.
5. GitHub will give you a temporary `github.io` address to test the site.
6. To use `ejctrivia.com`, first register/buy that domain through a domain registrar if you have not already bought it. In GitHub Pages settings, add `ejctrivia.com` as the custom domain, then set the DNS records exactly as GitHub instructs at your registrar. HTTPS may take a while to activate.

## Not a live quiz yet
This is the visual homepage only. Authentication, approval, tournament codes, admin panel, question bank, spreadsheet import, timers, server-side scoring, eliminations, leaderboard and audit logs must be built and tested before live competition. Never put service keys or passwords in public code.

## Anti-cheating limits
A browser can detect some tab visibility changes, but cannot reliably detect all screenshots, second-device use, AI assistance or every connection interruption. Explain the rules before the quiz and record detectable events transparently.
